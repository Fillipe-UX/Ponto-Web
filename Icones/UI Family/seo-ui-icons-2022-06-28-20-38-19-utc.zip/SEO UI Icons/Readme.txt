INTRODUCING
Pixel perfect icon set by mhudaaa. Perfect for your mobile apps website and presentations

FILES INCLUDED:
- PNG 512px for each file
- SVG for each file
- EPS
- Adobe Illustrator .AI

See more icons at :
https://elements.envato.com/user/mhudaaa/graphics

Hope you Like it.
Thanks.